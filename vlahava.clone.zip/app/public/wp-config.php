<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'r2N6q1ifNs+FrYcL8E9eLomZbI0zNObsMbFL08ASYNNObh5fuP5R9f3HDRBB7jMofovhDEIg3llwhcFlruPt4g==');
define('SECURE_AUTH_KEY',  'jt90WkEC2JqMfjV6mOobipkMrpsZFZ8dDzYlbOZfnPXvXV+v582bwovIzD5SUwynkhyQAz0dZgqYXTFbkspCGQ==');
define('LOGGED_IN_KEY',    'RIffREGsg8Mp25EIXkTe4zu6UU2Fbeilpge2B5fHjvK1pHhiYeEqO6D8Ln8T6v/Tgn1kElOd4Lo7zH09urSQqw==');
define('NONCE_KEY',        'QuM34T8z9NccgEYffafASMZ12i2Zl4J66dOT1XDpSxiYMu4t22TAUANYJnTX4srooxD9E/+GmRHpP8PhiaKP3g==');
define('AUTH_SALT',        'dZj76mRoXzM/777hxQSPV9s9x75WmkuXmOHXAUOqPQ21U1wnnT+335qV8MbI+5BbXOxs3Wm6lmYNCLY4KLbrKw==');
define('SECURE_AUTH_SALT', 'jnmmEurcu46kiC8smSLMAXtxTILcvLgFz9hlZkogTAX6NnqiKuIgUANeH9dnaR1cM2KB3isrfz893DNqGSqwUg==');
define('LOGGED_IN_SALT',   '54dKHahS5+6uTL94JA3+LyBJnqRQmj+T6OpicafDfOMTupuQwrfuUjt3SQUS56MpDD1+zJdicwhXs2Ri1vV3ZQ==');
define('NONCE_SALT',       'fXKyGNL/iu4bgITGFtlBk7QoMGbY37aOhjXNlDtGXg4xzNNFkMgOGzkYzbU/emus4tEIAuf5ips7ftnAfSq8uQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
